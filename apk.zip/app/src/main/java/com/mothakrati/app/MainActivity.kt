package com.mothakrati.app

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat
import androidx.webkit.WebViewAssetLoader

/**
 * غلاف WebView: بيعرض ملفات موقع "مذكرتي" المحطوطة جوه التطبيق (assets) فيشتغل أوفلاين،
 * وبيوفّر اختيار الملفات (استيراد) وحفظ الملفات (تصدير) ورسائل التنبيه والتأكيد.
 */
class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingBytes: ByteArray? = null

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCallback = null
    }

    private val saver = registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        val bytes = pendingBytes
        pendingBytes = null
        if (uri != null && bytes != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                toast("تم حفظ الملف ✅")
            } catch (e: Exception) {
                toast("تعذّر حفظ الملف")
            }
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    inner class Bridge {
        @JavascriptInterface
        fun saveBase64(name: String, mime: String, b64: String) {
            val bytes = try {
                Base64.decode(b64, Base64.DEFAULT)
            } catch (e: Exception) {
                return
            }
            runOnUiThread {
                pendingBytes = bytes
                saver.launch(name.ifBlank { "mothakrati.json" })
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        setContentView(web, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // الصفحة بتتحمّل من عنوان https آمن وهمي مربوط بملفات التطبيق، فـ localStorage وغيره بيشتغلوا عادي
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/$SITE_PATH/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.setSupportZoom(false)
        s.builtInZoomControls = false

        web.addJavascriptInterface(Bridge(), "AndroidBridge")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return loader.shouldInterceptRequest(request.url)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == HOST) return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                } catch (e: Exception) {
                }
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                view.evaluateJavascript(HOOK_JS, null)
                applyThemeColor()
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    chooser.launch(fileChooserParams.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }

            override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("حسناً") { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView, url: String, message: String, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("تأكيد") { _, _ -> result.confirm() }
                    .setNegativeButton("إلغاء") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsPrompt(
                view: WebView,
                url: String,
                message: String,
                defaultValue: String?,
                result: JsPromptResult
            ): Boolean {
                val input = EditText(this@MainActivity)
                input.setText(defaultValue ?: "")
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setView(input)
                    .setPositiveButton("حسناً") { _, _ -> result.confirm(input.text.toString()) }
                    .setNegativeButton("إلغاء") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }

        // احتياطي: لو الصفحة بدأت تنزيل عن طريق DownloadListener
        web.setDownloadListener { url, _, contentDisposition, mimeType, _ ->
            val name = URLUtil.guessFileName(url, contentDisposition, mimeType).replace("'", "")
            if (url.startsWith("data:")) {
                try {
                    val data = url.substringAfter(",")
                    val bytes = if (url.substringBefore(",").contains("base64")) Base64.decode(data, Base64.DEFAULT)
                    else Uri.decode(data).toByteArray()
                    pendingBytes = bytes
                    saver.launch(name)
                } catch (e: Exception) {
                    toast("تعذّر حفظ الملف")
                }
            } else if (url.startsWith("blob:")) {
                web.evaluateJavascript(
                    "(function(){fetch('" + url + "').then(function(r){return r.blob();}).then(function(b){" +
                            "var fr=new FileReader();fr.onloadend=function(){AndroidBridge.saveBase64('" + name + "'," +
                            "b.type||'application/octet-stream',String(fr.result).split(',')[1]||'');};fr.readAsDataURL(b);});})();",
                    null
                )
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        web.loadUrl("https://$HOST/$SITE_PATH/index.html")
    }

    /** لون شريط الحالة من meta theme-color بتاع الصفحة (لو موجود) */
    private fun applyThemeColor() {
        web.evaluateJavascript(
            "(function(){var m=document.querySelector('meta[name=theme-color]');return m?m.content:'';})()"
        ) { v ->
            val s = v?.trim('"') ?: ""
            try {
                val c = Color.parseColor(s)
                window.statusBarColor = c
                window.navigationBarColor = c
                val light = ColorUtils.calculateLuminance(c) > 0.5
                val ctl = WindowCompat.getInsetsController(window, web)
                ctl.isAppearanceLightStatusBars = light
                ctl.isAppearanceLightNavigationBars = light
            } catch (e: Exception) {
            }
        }
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        super.onDestroy()
    }

    companion object {
        const val HOST = "appassets.androidplatform.net"
        const val SITE_PATH = "mothakrati"

        // بيعترض زر "تصدير" (رابط تنزيل blob/data) ويحفظه من خلال التطبيق
        const val HOOK_JS = """
(function(){
 if(window.__mothHook) return; window.__mothHook=true;
 var orig=HTMLAnchorElement.prototype.click;
 HTMLAnchorElement.prototype.click=function(){
  var h=this.href||'';
  if(this.hasAttribute('download') && (h.indexOf('blob:')===0 || h.indexOf('data:')===0)){
   var name=this.getAttribute('download')||'file';
   fetch(h).then(function(r){return r.blob();}).then(function(b){
    var fr=new FileReader();
    fr.onloadend=function(){AndroidBridge.saveBase64(name,b.type||'application/octet-stream',String(fr.result).split(',')[1]||'');};
    fr.readAsDataURL(b);
   });
   return;
  }
  return orig.apply(this,arguments);
 };
})();
"""
    }
}
